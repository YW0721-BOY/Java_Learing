package com.HM.B_fileinputstream;

import java.io.FileInputStream;
import java.io.IOException;

public class ByteStreamDemo2 {
    public static void main(String[] args) throws IOException {
        /*
          字节输入流的细节：
             1.创建字节输入流对象
                        细节1：如果文件不存在，就直接报错。

                        JAVA为什么会这么设计？
                        输出流：不存在，会创建但是要保证父级路径存在
                                把数据写到文件中
                        输入流：不存在，报错
                             创建出来的文件是没有数据的，没有任何意义。
                             所以java就没有设计这种无意义的逻辑，文件不存在直接报错。
                        程序中最重要的是：数据。
             2.写数据
                        细节1：一次只读一个字节，读出来的是数据在ASCII上对应的数字
                        细节2：读到文件末尾了，read方法返回-1

             3.释放资源
                        细节1：每次使用完流之后都要释放资源
         */

        FileInputStream fis =new FileInputStream("23-1-26_io\\a.txt");

    }
}
